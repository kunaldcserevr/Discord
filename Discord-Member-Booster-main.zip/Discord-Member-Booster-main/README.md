# Discord Member Booster 🪐
The best member booster for discord, super easy to use and effective! What are you waiting for to increase your servers? Here I leave you a video preview and the functions it has.

## 📹 Preview

https://github.com/H4cK3dR4Du/Spotify-Account-Generator/assets/118562174/c9ba8753-ee6a-4fb4-86e7-5cd5e70f39ab

## 🔥 Features
- Fully Requests Based Generator
- Works With Paid Or Free Proxies
- HTTP & HTTPS Proxy Support
- Automatic Joins Server
- Multi-Threading support
- Fastest Member Booster
- Slick UI
- Simple & Easy To Setup
- 2Captcha & Capmonster & Capsolver Support
- Fast Captcha Solver
- Great Design
    
## ✍️ Usage
1. Edit the `proxies.txt` file and set your proxies
   
2. Edit the `config.json` file with your invite / captcha key

3. Open `main.py` and enjoy! :)

## ⚠️ DISCLAIMER
This github repo is for EDUCATIONAL PURPOSES ONLY. I am NOT under any responsibility if a problem occurs.

## ✨ Issues / Doubts

- If you have any questions do not hesitate to enter my discord: https://discord.gg/hcuxjpSfkU
- Or if you have any error do not forget to report it in: [issues](https://github.com/H4cK3dR4Du/Discord-Member-Booster/issues/new)
